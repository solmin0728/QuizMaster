﻿using UnityEngine;
using TMPro;
using System.Collections;

public class CountdownManager : MonoBehaviour
{
    public GameObject countdownPanel;  // 판넬 자체
    public TMP_Text countdownText;     // TMP_Text
    public float countInterval = 1f;   // 1초마다 카운트

    void Start()
    {
            countdownPanel.SetActive(true);

        StartCoroutine(CountdownRoutine());
    }

    IEnumerator CountdownRoutine()
    {
        int count = 3;
        while (count > 0)
        {
            countdownText.text = count.ToString();
            yield return new WaitForSeconds(countInterval);
            count--;
        }

        countdownText.text = "Go!";
        yield return new WaitForSeconds(countInterval);
    }
}
